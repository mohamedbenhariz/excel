﻿// Usage: MyApp.exe "C:\MyExcels" Status Done Amount

using System.IO;
using System;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {

#if DEBUG
        Console.Write("Enter folder path: ");
        string folderPath = Console.ReadLine();

        Console.Write("Filter column name: ");
        string filterColumn = Console.ReadLine();

        Console.Write("Filter value: ");
        string filterValue = Console.ReadLine();

        Console.Write("Column to sum: ");
        string sumColumn = Console.ReadLine();

#else
        if (args.Length < 4)
        {
            Console.WriteLine("Usage: Excel.exe <FolderPath> <FilterColumn> <FilterValue> <SumColumn>");
            return;
        }

        string folderPath = args[0];
        string filterColumn = args[1];
        string filterValue = args[2];
        string sumColumn = args[3];
#endif



        if (!Directory.Exists(folderPath))
        {
            Console.WriteLine("The folder does not exist.");
            return;
        }

        double totalSum = 0;

        foreach (var file in Directory.GetFiles(folderPath, "*.xlsx"))
        {
            using var workbook = new ClosedXML.Excel.XLWorkbook(file);
            var worksheet = workbook.Worksheet(1);
            var table = worksheet.RangeUsed().AsTable();

            var filteredRows = table.DataRange.Rows()
                .Where(r => r.Field(filterColumn).GetString() == filterValue);

            double sum = filteredRows.Sum(r => r.Field(sumColumn).GetDouble());

            Console.WriteLine($"{Path.GetFileName(file)} => {sum}");
            totalSum += sum;
        }

        Console.WriteLine($"\nTotal across all files: {totalSum}");
    }
}
